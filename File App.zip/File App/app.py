from flask import Flask, jsonify, request, g
from datetime import datetime, timezone
import os
import logging
import uuid
import time

app = Flask(__name__)

# Configura il logger principale
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)

# Middleware: inizio richiesta
@app.before_request
def start_request():
    g.request_id = str(uuid.uuid4())
    g.start_time = time.time()  # timestamp in secondi

# Middleware: fine richiesta e logging
@app.after_request
def log_request(response):
    # calcolo tempo di risposta in ms
    response_time_ms = round((time.time() - g.start_time) * 1000, 2)
    response.headers["X-Request-Id"] = g.request_id
    response.headers["X-Response-Time-ms"] = str(response_time_ms)

    logging.info(
        "RequestID=%s Method=%s Path=%s Status=%s Remote=%s ResponseTime=%sms",
        g.request_id,
        request.method,
        request.path,
        response.status_code,
        request.remote_addr,
        response_time_ms
    )
    return response

# Rotte
@app.route("/health")
def health():
    return jsonify({"status": "ok", "service": "demo-docker"})

@app.route("/time")
def get_time():
    now = datetime.now(timezone.utc).isoformat()
    return jsonify({"time": now, "request_id": g.request_id})

@app.route("/nope")
def nope():
    return jsonify({
        "error": "nope",
        "message": "This route does nothing useful!",
        "request_id": g.request_id
    }), 404

if __name__ == "__main__":
    # Disabilita logging automatico di Werkzeug per evitare doppio log
    werkzeug_log = logging.getLogger('werkzeug')
    werkzeug_log.setLevel(logging.ERROR)

    port = int(os.environ.get("PORT", "8000"))
    app.run(host="0.0.0.0", port=port)